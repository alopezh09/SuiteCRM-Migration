<?php
 // created: 2021-10-13 15:30:40
$layout_defs["NVC_Companies"]["subpanel_setup"]['nvc_companies_veta_requerimiento'] = array (
  'order' => 100,
  'module' => 'Veta_Requerimiento',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_NVC_COMPANIES_VETA_REQUERIMIENTO_FROM_VETA_REQUERIMIENTO_TITLE',
  'get_subpanel_data' => 'nvc_companies_veta_requerimiento',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
