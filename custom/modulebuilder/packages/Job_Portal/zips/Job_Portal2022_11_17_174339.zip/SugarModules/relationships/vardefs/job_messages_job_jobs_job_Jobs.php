<?php
// created: 2022-11-17 17:43:39
$dictionary["job_Jobs"]["fields"]["job_messages_job_jobs"] = array (
  'name' => 'job_messages_job_jobs',
  'type' => 'link',
  'relationship' => 'job_messages_job_jobs',
  'source' => 'non-db',
  'module' => 'job_Messages',
  'bean_name' => 'job_Messages',
  'vname' => 'LBL_JOB_MESSAGES_JOB_JOBS_FROM_JOB_MESSAGES_TITLE',
);
