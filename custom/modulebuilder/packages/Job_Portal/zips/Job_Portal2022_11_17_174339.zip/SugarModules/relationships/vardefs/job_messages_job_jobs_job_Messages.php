<?php
// created: 2022-11-17 17:43:39
$dictionary["job_Messages"]["fields"]["job_messages_job_jobs"] = array (
  'name' => 'job_messages_job_jobs',
  'type' => 'link',
  'relationship' => 'job_messages_job_jobs',
  'source' => 'non-db',
  'module' => 'job_Jobs',
  'bean_name' => 'job_Jobs',
  'vname' => 'LBL_JOB_MESSAGES_JOB_JOBS_FROM_JOB_JOBS_TITLE',
);
