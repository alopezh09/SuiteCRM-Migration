<?php
// created: 2024-04-15 16:33:49
$dictionary["Veta_Requerimiento"]["fields"]["veta_profile_veta_requerimiento"] = array (
  'name' => 'veta_profile_veta_requerimiento',
  'type' => 'link',
  'relationship' => 'veta_profile_veta_requerimiento',
  'source' => 'non-db',
  'module' => 'Veta_Profile',
  'bean_name' => 'Veta_Profile',
  'vname' => 'LBL_VETA_PROFILE_VETA_REQUERIMIENTO_FROM_VETA_PROFILE_TITLE',
  'id_name' => 'veta_profile_veta_requerimientoveta_profile_ida',
);
$dictionary["Veta_Requerimiento"]["fields"]["veta_profile_veta_requerimiento_name"] = array (
  'name' => 'veta_profile_veta_requerimiento_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_VETA_PROFILE_VETA_REQUERIMIENTO_FROM_VETA_PROFILE_TITLE',
  'save' => true,
  'id_name' => 'veta_profile_veta_requerimientoveta_profile_ida',
  'link' => 'veta_profile_veta_requerimiento',
  'table' => 'veta_profile',
  'module' => 'Veta_Profile',
  'rname' => 'name',
);
$dictionary["Veta_Requerimiento"]["fields"]["veta_profile_veta_requerimientoveta_profile_ida"] = array (
  'name' => 'veta_profile_veta_requerimientoveta_profile_ida',
  'type' => 'link',
  'relationship' => 'veta_profile_veta_requerimiento',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'left',
  'vname' => 'LBL_VETA_PROFILE_VETA_REQUERIMIENTO_FROM_VETA_PROFILE_TITLE',
);
