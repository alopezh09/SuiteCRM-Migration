<?php
 // created: 2021-10-19 17:13:53
$dictionary['Veta_Requerimiento']['fields']['company_total_c']['inline_edit']='1';
$dictionary['Veta_Requerimiento']['fields']['company_total_c']['labelValue']='Company total to pay';

 ?>