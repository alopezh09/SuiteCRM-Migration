<?php
 // created: 2021-10-15 16:17:20
$dictionary['Veta_Requerimiento']['fields']['company_lead_id_c']['inline_edit']='';
$dictionary['Veta_Requerimiento']['fields']['company_lead_id_c']['labelValue']='Company Lead ID';

 ?>