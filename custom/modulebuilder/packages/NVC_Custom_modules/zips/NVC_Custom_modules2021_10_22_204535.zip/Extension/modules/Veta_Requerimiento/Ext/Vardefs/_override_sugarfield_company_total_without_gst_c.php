<?php
 // created: 2021-10-14 21:34:07
$dictionary['Veta_Requerimiento']['fields']['company_total_without_gst_c']['inline_edit']='1';
$dictionary['Veta_Requerimiento']['fields']['company_total_without_gst_c']['labelValue']='Company total Without GST';

 ?>