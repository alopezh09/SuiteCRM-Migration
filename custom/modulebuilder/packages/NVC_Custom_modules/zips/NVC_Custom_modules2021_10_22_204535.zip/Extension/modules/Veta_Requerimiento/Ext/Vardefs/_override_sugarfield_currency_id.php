<?php
 // created: 2021-10-14 21:32:25
$dictionary['Veta_Requerimiento']['fields']['currency_id']['inline_edit']=1;

 ?>