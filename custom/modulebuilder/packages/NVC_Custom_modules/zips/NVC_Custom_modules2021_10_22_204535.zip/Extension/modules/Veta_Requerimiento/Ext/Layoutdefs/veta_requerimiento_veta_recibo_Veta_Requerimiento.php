<?php
 // created: 2020-09-10 02:09:35
$layout_defs["Veta_Requerimiento"]["subpanel_setup"]['veta_requerimiento_veta_recibo'] = array (
  'order' => 100,
  'module' => 'Veta_Recibo',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_VETA_REQUERIMIENTO_VETA_RECIBO_FROM_VETA_RECIBO_TITLE2',
  'get_subpanel_data' => 'veta_requerimiento_veta_recibo',
  'top_buttons' => 
  array (
    /* 0 =>
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),     */
    
  ),
);
