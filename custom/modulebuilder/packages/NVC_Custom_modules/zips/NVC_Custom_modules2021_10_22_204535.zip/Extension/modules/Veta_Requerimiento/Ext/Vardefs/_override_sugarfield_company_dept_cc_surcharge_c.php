<?php
 // created: 2021-10-14 21:36:24
$dictionary['Veta_Requerimiento']['fields']['company_dept_cc_surcharge_c']['inline_edit']='1';
$dictionary['Veta_Requerimiento']['fields']['company_dept_cc_surcharge_c']['labelValue']='Company Department Credit Card Surcharge percentage';

 ?>