<?php
 // created: 2021-10-14 21:33:27
$dictionary['Veta_Requerimiento']['fields']['company_deposits_c']['inline_edit']='1';
$dictionary['Veta_Requerimiento']['fields']['company_deposits_c']['labelValue']='Company Deposits';

 ?>