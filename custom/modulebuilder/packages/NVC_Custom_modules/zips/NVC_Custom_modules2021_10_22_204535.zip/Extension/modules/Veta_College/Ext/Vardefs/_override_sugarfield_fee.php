<?php
 // created: 2021-10-14 15:38:02
$dictionary['Veta_College']['fields']['fee']['default']='0';

 ?>