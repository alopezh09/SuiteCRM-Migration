<?php
 // created: 2021-10-18 19:36:29
$dictionary['Veta_Presupuesto']['fields']['total_visa_company_c']['inline_edit']='';
$dictionary['Veta_Presupuesto']['fields']['total_visa_company_c']['labelValue']='Total Visa Company';

 ?>