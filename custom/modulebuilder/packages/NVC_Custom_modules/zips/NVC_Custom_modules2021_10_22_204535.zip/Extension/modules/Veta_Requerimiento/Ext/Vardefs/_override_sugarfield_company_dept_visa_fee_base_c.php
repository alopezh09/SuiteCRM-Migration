<?php
 // created: 2021-10-14 21:38:16
$dictionary['Veta_Requerimiento']['fields']['company_dept_visa_fee_base_c']['inline_edit']='1';
$dictionary['Veta_Requerimiento']['fields']['company_dept_visa_fee_base_c']['labelValue']='Company Department Visa Fee Base application charge';

 ?>