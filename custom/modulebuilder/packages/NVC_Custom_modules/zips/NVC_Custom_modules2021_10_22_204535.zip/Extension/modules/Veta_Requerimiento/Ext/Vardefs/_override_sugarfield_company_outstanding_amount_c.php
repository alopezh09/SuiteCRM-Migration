<?php
 // created: 2021-10-14 21:32:25
$dictionary['Veta_Requerimiento']['fields']['company_outstanding_amount_c']['inline_edit']='1';
$dictionary['Veta_Requerimiento']['fields']['company_outstanding_amount_c']['labelValue']='Company Outstanding Amount';

 ?>