<?php
 // created: 2021-10-19 18:57:24
$dictionary['Veta_Requerimiento']['fields']['company_discount_c']['inline_edit']='1';
$dictionary['Veta_Requerimiento']['fields']['company_discount_c']['labelValue']='Company Discount';

 ?>