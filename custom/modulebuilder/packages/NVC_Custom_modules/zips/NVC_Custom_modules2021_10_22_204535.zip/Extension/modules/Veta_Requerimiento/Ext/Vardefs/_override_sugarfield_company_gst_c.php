<?php
 // created: 2021-10-14 21:34:28
$dictionary['Veta_Requerimiento']['fields']['company_gst_c']['inline_edit']='1';
$dictionary['Veta_Requerimiento']['fields']['company_gst_c']['labelValue']='Company GST';

 ?>