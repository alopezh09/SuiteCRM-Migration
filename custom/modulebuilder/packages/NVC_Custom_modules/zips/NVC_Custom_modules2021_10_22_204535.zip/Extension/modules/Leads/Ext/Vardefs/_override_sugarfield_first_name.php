<?php
 // created: 2020-10-08 23:20:50
$dictionary['Lead']['fields']['first_name']['inline_edit']='';
$dictionary['Lead']['fields']['first_name']['comments']='First name of the contact';
$dictionary['Lead']['fields']['first_name']['merge_filter']='disabled';

 ?>