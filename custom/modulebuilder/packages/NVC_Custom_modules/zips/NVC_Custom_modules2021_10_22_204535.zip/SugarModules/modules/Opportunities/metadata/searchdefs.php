<?php
$searchdefs ['Opportunities'] = 
array (
  'layout' => 
  array (
    'basic_search' => 
    array (
      'name' => 
      array (
        'name' => 'name',
        'default' => true,
        'width' => '10%',
      ),
      'contacts_opportunities_1_name' => 
      array (
        'type' => 'relate',
        'link' => true,
        'label' => 'LBL_CONTACTS_OPPORTUNITIES_1_FROM_CONTACTS_TITLE',
        'id' => 'CONTACTS_OPPORTUNITIES_1CONTACTS_IDA',
        'width' => '10%',
        'default' => true,
        'name' => 'contacts_opportunities_1_name',
      ),
      'leads_opportunities_1_name' => 
      array (
        'type' => 'relate',
        'link' => true,
        'label' => 'LBL_LEADS_OPPORTUNITIES_1_FROM_LEADS_TITLE',
        'width' => '10%',
        'default' => true,
        'id' => 'LEADS_OPPORTUNITIES_1LEADS_IDA',
        'name' => 'leads_opportunities_1_name',
      ),
      'soel_oficina' => 
      array (
        'type' => 'enum',
        'label' => 'LBL_SOEL_OFICINA',
        'width' => '10%',
        'default' => true,
        'name' => 'soel_oficina',
        'sortable' => false,
        'function' => 
        array (
          'name' => 'getOficinasComercial',
        ),
      ),
    ),
    'advanced_search' => 
    array (
      'name' => 
      array (
        'name' => 'name',
        'default' => true,
        'width' => '10%',
      ),
      'sales_stage' => 
      array (
        'name' => 'sales_stage',
        'default' => true,
        'width' => '10%',
      ),
      'lead_source' => 
      array (
        'name' => 'lead_source',
        'default' => true,
        'width' => '10%',
      ),
      'fecha_cierre_c' => 
      array (
        'type' => 'datetimecombo',
        'default' => true,
        'label' => 'LBL_FECHA_CIERRE',
        'width' => '10%',
        'name' => 'fecha_cierre_c',
      ),
      'contacts_opportunities_1_name' => 
      array (
        'type' => 'relate',
        'link' => true,
        'label' => 'LBL_CONTACTS_OPPORTUNITIES_1_FROM_CONTACTS_TITLE',
        'width' => '10%',
        'default' => true,
        'id' => 'CONTACTS_OPPORTUNITIES_1CONTACTS_IDA',
        'name' => 'contacts_opportunities_1_name',
      ),
      'leads_opportunities_1_name' => 
      array (
        'type' => 'relate',
        'link' => true,
        'label' => 'LBL_LEADS_OPPORTUNITIES_1_FROM_LEADS_TITLE',
        'id' => 'LEADS_OPPORTUNITIES_1LEADS_IDA',
        'width' => '10%',
        'default' => true,
        'name' => 'leads_opportunities_1_name',
      ),
      'assigned_user_id' => 
      array (
        'name' => 'assigned_user_id',
        'type' => 'enum',
        'label' => 'LBL_ASSIGNED_TO',
        'function' => 
        array (
          'name' => 'get_user_array',
          'params' => 
          array (
            0 => false,
          ),
        ),
        'default' => true,
        'width' => '10%',
      ),
      'asignado_servicio_cliente_c' => 
      array (
        'type' => 'relate',
        'default' => true,
        'studio' => 'visible',
        'label' => 'LBL_ASIGNADO_SERVICIO_CLIENTE',
        'id' => 'USER_ID2_C',
        'link' => true,
        'width' => '10%',
        'name' => 'asignado_servicio_cliente_c',
      ),
      'asignado_aplicacion_c' => 
      array (
        'type' => 'relate',
        'default' => true,
        'studio' => 'visible',
        'label' => 'LBL_ASIGNADO_APLICACION',
        'id' => 'USER_ID_C',
        'link' => true,
        'width' => '10%',
        'name' => 'asignado_aplicacion_c',
      ),
      'asignado_visas_c' => 
      array (
        'type' => 'relate',
        'default' => true,
        'studio' => 'visible',
        'label' => 'LBL_ASIGNADO_VISAS',
        'id' => 'USER_ID1_C',
        'link' => true,
        'width' => '10%',
        'name' => 'asignado_visas_c',
      ),
      'estado_gestion_comercial_c' => 
      array (
        'type' => 'enum',
        'default' => true,
        'studio' => 'visible',
        'label' => 'LBL_ESTADO_GESTION_COMERCIAL',
        'width' => '10%',
        'name' => 'estado_gestion_comercial_c',
      ),
      'estado_cartera_c' => 
      array (
        'type' => 'enum',
        'default' => true,
        'studio' => 'visible',
        'label' => 'LBL_ESTADO_CARTERA',
        'width' => '10%',
        'name' => 'estado_cartera_c',
      ),
      'estado_recoleccion_documento_c' => 
      array (
        'type' => 'enum',
        'default' => true,
        'studio' => 'visible',
        'label' => 'LBL_ESTADO_RECOLECCION_DOCUMENTO',
        'width' => '10%',
        'name' => 'estado_recoleccion_documento_c',
      ),
      'estado_servicio_al_cliente_c' => 
      array (
        'type' => 'enum',
        'default' => true,
        'studio' => 'visible',
        'label' => 'LBL_ESTADO_SERVICIO_AL_CLIENTE',
        'width' => '10%',
        'name' => 'estado_servicio_al_cliente_c',
      ),
      'estado_visas_c' => 
      array (
        'type' => 'enum',
        'default' => true,
        'studio' => 'visible',
        'label' => 'LBL_ESTADO_VISAS',
        'width' => '10%',
        'name' => 'estado_visas_c',
      ),
      'industry_aplicant' => 
      array (
        'type' => 'varchar',
        'default' => true,
        'label' => 'LBL_INDUSTRY_APLICANT',
        'width' => '10%',
        'name' => 'industry_aplicant',
        'sortable' => false,
      ),
      'aplicant_first_payment_amount' => 
      array (
        'type' => 'varchar',
        'default' => true,
        'label' => 'LBL_APPLICANT_FIRST_PAYMENT_AMOUNT',
        'width' => '10%',
        'name' => 'aplicant_first_payment_amount',
        'sortable' => false,
      ),
      'profession' => 
      array (
        'type' => 'varchar',
        'default' => true,
        'label' => 'LBL_PROFESSION',
        'width' => '10%',
        'name' => 'profession',
        'sortable' => false,
      ),
      'current_visa_subclass' => 
      array (
        'type' => 'varchar',
        'default' => true,
        'label' => 'LBL_CURRENT_VISA_SUBCLASS',
        'width' => '10%',
        'name' => 'current_visa_subclass',
        'sortable' => false,
      ),
      'current_job_position' => 
      array (
        'type' => 'varchar',
        'default' => true,
        'label' => 'LBL_CURRENT_JOB_POSITION',
        'width' => '10%',
        'name' => 'current_job_position',
        'sortable' => false,
      ),
      'month_of_experience' => 
      array (
        'type' => 'varchar',
        'default' => true,
        'label' => 'LBL_MONTHS_OF_EXPERIENCEL',
        'width' => '10%',
        'name' => 'month_of_experience',
        'sortable' => false,
      ),
      'level_of_english' => 
      array (
        'type' => 'varchar',
        'default' => true,
        'label' => 'LBL_LEVEL_OF_ENGLISH',
        'width' => '10%',
        'name' => 'level_of_english',
        'sortable' => false,
      ),
      'nationality' => 
      array (
        'type' => 'varchar',
        'default' => true,
        'label' => 'LBL_NATIONALITY',
        'width' => '10%',
        'name' => 'nationality',
        'sortable' => false,
      ),
      'potential_visa_subclass' => 
      array (
        'type' => 'varchar',
        'default' => true,
        'label' => 'LBL_POTENTIAL_VISA_SUBCLASS',
        'width' => '10%',
        'name' => 'potential_visa_subclass',
        'sortable' => false,
      ),
      'cost_agrement_number' => 
      array (
        'type' => 'varchar',
        'default' => true,
        'label' => 'LBL_COST_AGREMENT_NUMBER',
        'width' => '10%',
        'name' => 'cost_agrement_number',
        'sortable' => false,
      ),
      'cost_agrement_visa_subclass' => 
      array (
        'type' => 'varchar',
        'default' => true,
        'label' => 'LBL_COST_AGREMENT_VISA_SUBCLASS',
        'width' => '10%',
        'name' => 'cost_agrement_visa_subclass',
        'sortable' => false,
      ),
      'migration_agent_name' => 
      array (
        'type' => 'varchar',
        'default' => true,
        'label' => 'LBL_MIGRATION_AGENT_NAME',
        'width' => '10%',
        'name' => 'migration_agent_name',
        'sortable' => false,
      ),
      'leap_id' => 
      array (
        'type' => 'varchar',
        'default' => true,
        'label' => 'LBL_LEAP_ID',
        'width' => '10%',
        'name' => 'leap_id',
        'sortable' => false,
      ),
      'recluter_name' => 
      array (
        'type' => 'varchar',
        'default' => true,
        'label' => 'LBL_RECLUTER_NAME',
        'width' => '10%',
        'name' => 'recluter_name',
        'sortable' => false,
      ),
      'company_name' => 
      array (
        'type' => 'varchar',
        'default' => true,
        'label' => 'LBL_COMPANY_NAME',
        'width' => '10%',
        'name' => 'company_name',
        'sortable' => false,
      ),
      'company_city' => 
      array (
        'type' => 'varchar',
        'default' => true,
        'label' => 'LBL_COMPANY_CITY',
        'width' => '10%',
        'name' => 'company_city',
        'sortable' => false,
      ),
      'company_industry' => 
      array (
        'type' => 'varchar',
        'default' => true,
        'label' => 'LBL_COMPANY_INDUSTRY',
        'width' => '10%',
        'name' => 'company_industry',
        'sortable' => false,
      ),
      'email_company' => 
      array (
        'type' => 'varchar',
        'default' => true,
        'label' => 'LBL_EMAIL_COMPANY',
        'width' => '10%',
        'name' => 'email_company',
        'sortable' => false,
      ),
      'phone_company' => 
      array (
        'type' => 'varchar',
        'default' => true,
        'label' => 'LBL_PHONE_COMPANY',
        'width' => '10%',
        'name' => 'phone_company',
        'sortable' => false,
      ),
      'company_first_payment_amount' => 
      array (
        'type' => 'varchar',
        'default' => true,
        'label' => 'LBL_COMPANY_FIRST_PAYMENT_AMOUNT',
        'width' => '10%',
        'name' => 'company_first_payment_amount',
        'sortable' => false,
      ),
      'secondary_aplicant_name' => 
      array (
        'type' => 'varchar',
        'default' => true,
        'label' => 'LBL_SECONDARY_APLICANT_NAME',
        'width' => '10%',
        'name' => 'secondary_aplicant_name',
        'sortable' => false,
      ),
      'secondary_pasport_number' => 
      array (
        'type' => 'varchar',
        'default' => true,
        'label' => 'LBL_SECONDARY_PASPORT_NUMBER',
        'width' => '10%',
        'name' => 'secondary_pasport_number',
        'sortable' => false,
      ),
      'dependent_name' => 
      array (
        'type' => 'varchar',
        'default' => true,
        'label' => 'LBL_DEPENDENT_NAME',
        'width' => '10%',
        'name' => 'dependent_name',
        'sortable' => false,
      ),
      'aplicant_mmm_fee' => 
      array (
        'type' => 'varchar',
        'default' => true,
        'label' => 'LBL_APLICANT_MMM_FEE',
        'width' => '10%',
        'name' => 'aplicant_mmm_fee',
        'sortable' => false,
      ),
      'second_dependent_name' => 
      array (
        'type' => 'varchar',
        'default' => true,
        'label' => 'LBL_SECOND_DEPENDENT_NAME',
        'width' => '10%',
        'name' => 'second_dependent_name',
        'sortable' => false,
      ),
      'third_dependent_name' => 
      array (
        'type' => 'varchar',
        'default' => true,
        'label' => 'LBL_THIRD_DEPENDENT_NAME',
        'width' => '10%',
        'name' => 'third_dependent_name',
        'sortable' => false,
      ),
      'consultation_fee' => 
      array (
        'type' => 'varchar',
        'default' => true,
        'label' => 'LBL_CONSULTATION_FEE',
        'width' => '10%',
        'name' => 'consultation_fee',
        'sortable' => false,
      ),
      'aplicant_departments_visa_fee' => 
      array (
        'type' => 'varchar',
        'default' => true,
        'label' => 'LBL_APLICANT_DEPARTMENTS_VISA_FEE',
        'width' => '10%',
        'name' => 'aplicant_departments_visa_fee',
        'sortable' => false,
      ),
      'company_mmm_fee' => 
      array (
        'type' => 'varchar',
        'default' => true,
        'label' => 'LBL_COMPANY_MMM_FEE',
        'width' => '10%',
        'name' => 'company_mmm_fee',
        'sortable' => false,
      ),
      'aplicant_company_mmm' => 
      array (
        'type' => 'varchar',
        'default' => true,
        'label' => 'LBL_APLICANT_COMPANY_MMM',
        'width' => '10%',
        'name' => 'aplicant_company_mmm',
        'sortable' => false,
      ),
      'total' => 
      array (
        'type' => 'varchar',
        'default' => true,
        'label' => 'LBL_TOTAL',
        'width' => '10%',
        'name' => 'total',
        'sortable' => false,
      ),
      'aplicant_company_mmm_fees' => 
      array (
        'type' => 'varchar',
        'default' => true,
        'label' => 'LBL_APLICANT_COMPANY_MMM_FEES',
        'width' => '10%',
        'name' => 'aplicant_company_mmm_fees',
        'sortable' => false,
      ),
      'total_paid' => 
      array (
        'type' => 'varchar',
        'default' => true,
        'label' => 'LBL_TOTAL_PAID',
        'width' => '10%',
        'name' => 'total_paid',
        'sortable' => false,
      ),
      'ocupation' => 
      array (
        'type' => 'varchar',
        'default' => true,
        'label' => 'LBL_OCUPATION',
        'width' => '10%',
        'name' => 'ocupation',
        'sortable' => false,
      ),
      'main_aplicant_name' => 
      array (
        'type' => 'varchar',
        'default' => true,
        'label' => 'LBL_MAIN_APLICANT_NAME',
        'width' => '10%',
        'name' => 'main_aplicant_name',
        'sortable' => false,
      ),
      'fecha_ultimo_contacto_c' => 
      array (
        'type' => 'datetimecombo',
        'default' => true,
        'label' => 'LBL_FECHA_ULTIMO_CONTACTO',
        'width' => '10%',
        'name' => 'fecha_ultimo_contacto_c',
      ),
      'fecha_proximo_contacto_c' => 
      array (
        'type' => 'datetimecombo',
        'default' => true,
        'label' => 'LBL_FECHA_PROXIMO_CONTACTO',
        'width' => '10%',
        'name' => 'fecha_proximo_contacto_c',
      ),
      'fecha_aplicacion_visa_c' => 
      array (
        'type' => 'date',
        'default' => true,
        'label' => 'LBL_FECHA_APLICACION_VISA',
        'width' => '10%',
        'name' => 'fecha_aplicacion_visa_c',
      ),
      'date_entered' => 
      array (
        'type' => 'datetime',
        'label' => 'LBL_DATE_ENTERED',
        'width' => '10%',
        'default' => true,
        'name' => 'date_entered',
      ),
      'soel_fecha_viaje' => 
      array (
        'type' => 'datetime',
        'default' => true,
        'label' => 'LBL_SOEL_FECHA_VIAJE',
        'width' => '10%',
        'name' => 'soel_fecha_viaje',
        'sortable' => false,
      ),
      'soel_fecha_expiracion_visa' => 
      array (
        'type' => 'datetime',
        'default' => true,
        'label' => 'LBL_SOEL_FECHA_EXPIRACION_VISA',
        'width' => '10%',
        'name' => 'soel_fecha_expiracion_visa',
        'sortable' => false,
      ),
      'soel_visto_bueno_comercial' => 
      array (
        'type' => 'bool',
        'default' => true,
        'label' => 'LBL_SOEL_VISTO_BUENO_COMERCIAL',
        'width' => '10%',
        'name' => 'soel_visto_bueno_comercial',
        'sortable' => false,
      ),
      'soel_visto_bueno_visas' => 
      array (
        'type' => 'bool',
        'default' => true,
        'label' => 'LBL_SOEL_VISTO_BUENO_VISAS',
        'width' => '10%',
        'name' => 'soel_visto_bueno_visas',
        'sortable' => false,
      ),
      'soel_oficina' => 
      array (
        'type' => 'enum',
        'label' => 'LBL_SOEL_OFICINA',
        'width' => '10%',
        'default' => true,
        'sortable' => false,
        'name' => 'soel_oficina',
      ),
      'soel_referido' => 
      array (
        'type' => 'varchar',
        'default' => true,
        'label' => 'LBL_SOEL_REFERIDO',
        'width' => '10%',
        'name' => 'soel_referido',
        'sortable' => false,
      ),
      'soel_date_estudiante' => 
      array (
        'type' => 'datetime',
        'label' => 'LBL_SOEL_DATE_ESTUDIANTE',
        'width' => '10%',
        'default' => true,
        'name' => 'soel_date_estudiante',
      ),
      'soel_date_asesor' => 
      array (
        'type' => 'datetime',
        'label' => 'LBL_SOEL_DATE_ASESOR',
        'width' => '10%',
        'default' => true,
        'name' => 'soel_date_asesor',
      ),
      'soel_docs_solicitados' => 
      array (
        'type' => 'varchar',
        'label' => 'LBL_SOEL_DOCS_SOLICITADOS',
        'width' => '10%',
        'default' => true,
        'name' => 'soel_docs_solicitados',
      ),
      'soel_docs_pendientes' => 
      array (
        'type' => 'varchar',
        'label' => 'LBL_SOEL_DOCS_PENDIENTES',
        'width' => '10%',
        'default' => true,
        'name' => 'soel_docs_pendientes',
      ),
      'consultation_date' => 
      array (
        'type' => 'datetime',
        'label' => 'LBL_CONSULTATION_DATE',
        'width' => '10%',
        'default' => true,
        'name' => 'consultation_date',
      ),
      'aplicant_1st_payment_date' => 
      array (
        'type' => 'datetime',
        'default' => true,
        'label' => 'LBL_APPLICANT_1ST_PAYMENT_DATE',
        'width' => '10%',
        'name' => 'aplicant_1st_payment_date',
        'sortable' => false,
      ),
      'quote_date' => 
      array (
        'type' => 'datetime',
        'default' => true,
        'label' => 'LBL_QUOTE_DATE',
        'width' => '10%',
        'name' => 'quote_date',
        'sortable' => false,
      ),
      'company_1st_payment_date' => 
      array (
        'type' => 'datetime',
        'default' => true,
        'label' => 'LBL_COMPANY_1ST_PAYMENT_DATE',
        'width' => '10%',
        'name' => 'company_1st_payment_date',
        'sortable' => false,
      ),
      'company_sbs_expiry_date' => 
      array (
        'type' => 'datetime',
        'default' => true,
        'label' => 'LBL_COMPANY_SBS_EXPIRY_DATE',
        'width' => '10%',
        'name' => 'company_sbs_expiry_date',
        'sortable' => false,
      ),
      'secondary_dob' => 
      array (
        'type' => 'datetime',
        'default' => true,
        'label' => 'LBL_SECONDARY_DOB',
        'width' => '10%',
        'name' => 'secondary_dob',
        'sortable' => false,
      ),
      'dependent_dob' => 
      array (
        'type' => 'datetime',
        'default' => true,
        'label' => 'LBL_DEPENDENT_DOB',
        'width' => '10%',
        'name' => 'dependent_dob',
        'sortable' => false,
      ),
      'second_dependent_dob' => 
      array (
        'type' => 'datetime',
        'default' => true,
        'label' => 'LBL_SECOND_DEPENDENT_DOB',
        'width' => '10%',
        'name' => 'second_dependent_dob',
        'sortable' => false,
      ),
      'recruitment_exp_date' => 
      array (
        'type' => 'datetime',
        'default' => true,
        'label' => 'LBL_RECRUITMENT_EXP_DATE',
        'width' => '10%',
        'name' => 'recruitment_exp_date',
        'sortable' => false,
      ),
      'visa_app_date' => 
      array (
        'type' => 'datetime',
        'default' => true,
        'label' => 'LBL_VISA_APP_DATE',
        'width' => '10%',
        'name' => 'visa_app_date',
        'sortable' => false,
      ),
      'visa_app_exp_date' => 
      array (
        'type' => 'datetime',
        'default' => true,
        'label' => 'LBL_VISA_APP_EXP_DATE',
        'width' => '10%',
        'name' => 'visa_app_exp_date',
        'sortable' => false,
      ),
      'skill_assessment_app_date' => 
      array (
        'type' => 'datetime',
        'default' => true,
        'label' => 'LBL_SKILL_ASSESSMENT_APP_DATE',
        'width' => '10%',
        'name' => 'skill_assessment_app_date',
        'sortable' => false,
      ),
      'skill_assessment_app_exp_date' => 
      array (
        'type' => 'datetime',
        'default' => true,
        'label' => 'LBL_SKILL_ASSESSMENT_APP_EXP_DATE',
        'width' => '10%',
        'name' => 'skill_assessment_app_exp_date',
        'sortable' => false,
      ),
      'nomination_app_date' => 
      array (
        'type' => 'datetime',
        'default' => true,
        'label' => 'LBL_NOMINATION_APP_DATE',
        'width' => '10%',
        'name' => 'nomination_app_date',
        'sortable' => false,
      ),
      'nomination_app_exp_date' => 
      array (
        'type' => 'datetime',
        'default' => true,
        'label' => 'LBL_NOMINATION_APP_EXP_DATE',
        'width' => '10%',
        'name' => 'nomination_app_exp_date',
        'sortable' => false,
      ),
    ),
  ),
  'templateMeta' => 
  array (
    'maxColumns' => '3',
    'maxColumnsBasic' => '4',
    'widths' => 
    array (
      'label' => '10',
      'field' => '30',
    ),
  ),
);
;
?>
