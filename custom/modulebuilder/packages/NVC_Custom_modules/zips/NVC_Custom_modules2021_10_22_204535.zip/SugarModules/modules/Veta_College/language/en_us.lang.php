<?php 
 // created: 2021-10-22 20:44:47
$mod_strings['LBL_COMPANY_FEE'] = 'Company Fee';
$mod_strings['LBL_FEE'] = 'Fee';

?>
