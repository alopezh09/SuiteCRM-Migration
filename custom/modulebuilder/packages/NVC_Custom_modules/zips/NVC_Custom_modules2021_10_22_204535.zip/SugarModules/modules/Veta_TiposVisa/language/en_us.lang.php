<?php 
 // created: 2021-10-22 20:45:04
$mod_strings['LBL_COMPANY_TOTAL_VISA'] = 'Company total visa';

?>
