<?php 
 // created: 2021-10-22 20:44:53
$mod_strings['LBL_VETA_ABONO_VETA_RECIBO_FROM_VETA_ABONO_TITLE'] = 'Applicant Deposits';
$mod_strings['LBL_VETA_RECIBO_CONTACTS_FROM_CONTACTS_TITLE'] = 'Clients';
$mod_strings['LBL_USD'] = 'Dolar';
$mod_strings['LBL_COMPANY_DISCOUNT'] = 'Company Discount';
$mod_strings['LBL_TOTAL_VISA_COMPANY'] = 'Total Visa Company';
$mod_strings['LBL_DETAILVIEW_PANEL3'] = 'COMPANY TOTALS';
$mod_strings['LBL_VETA_RECIBO_NVC_DEPOSIT_COMPANY_1_FROM_NVC_DEPOSIT_COMPANY_TITLE'] = 'Deposit Company';
$mod_strings['LBL_COMPANY_OUTSTANDING_AMOUNT'] = 'Company Outstanding Amount';
$mod_strings['LBL_DETAILVIEW_PANEL2'] = 'APPLICANT TOTALS';
$mod_strings['LBL_COMPANY_GRAND_TOTAL'] = 'Company Grand Total';
$mod_strings['LBL_COMPANY_PAID'] = 'Company Paid';

?>
