<?php 
 // created: 2021-10-22 20:45:04
$mod_strings['LBL_FECHA_FIRMA_ACTA'] = 'Fecha Firma Acta';
$mod_strings['LBL_FECHA_APLICACION'] = 'Fecha Aplicación';
$mod_strings['LBL_FECHA_AVAC'] = 'Fecha Avac';
$mod_strings['LBL_FECHA_EXP_REQ1'] = 'Fecha de Expiracion Requerimiento 1';
$mod_strings['LBL_FECHA_EXPIRACION_REQUERIMIENTO'] = 'Fecha de Expiración del Requerimiento';

?>
