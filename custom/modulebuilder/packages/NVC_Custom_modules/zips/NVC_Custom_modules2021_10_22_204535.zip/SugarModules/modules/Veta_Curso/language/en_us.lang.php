<?php 
 // created: 2021-10-22 20:44:48
$mod_strings['LBL_TERMS_AND_CONDITIONS_COMPANY'] = 'Company Terms and conditions';
$mod_strings['LBL_DESCRIPTION'] = 'Applicant Term and conditions';
$mod_strings['LBL_COSTO_EXTRA'] = 'Extra Costs';
$mod_strings['LBL_COSTO_MATERIALES'] = 'Materials Cost';
$mod_strings['LBL_DEPOSITO'] = 'Deposit';
$mod_strings['LBL_DURACION'] = 'Duration';
$mod_strings['LBL_EXAMEN_MEDICO'] = 'Medical Test';
$mod_strings['LBL_FECHA_EXPIRACION'] = 'Expiration Date';
$mod_strings['LBL_INSCRIPCION'] = 'Enrolment (Enrolment Fee)';
$mod_strings['LBL_INTENSIDAD'] = 'Intensity';
$mod_strings['LBL_PPS'] = 'Weekly cost';
$mod_strings['LBL_SEGURO'] = 'Insurance value';
$mod_strings['LBL_TIPO_CURSO'] = 'Visa Subclass Type';
$mod_strings['LBL_VACACIONES'] = 'Vacations';
$mod_strings['LBL_VISA'] = 'Visa Cost';

?>
