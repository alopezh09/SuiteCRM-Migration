<?php 
 // created: 2021-10-22 20:44:47
$mod_strings['LBL_MONTO'] = 'Amount';
$mod_strings['LBL_NAME'] = 'Number';
$mod_strings['LBL_VETA_ABONO_VETA_RECIBO_FROM_VETA_RECIBO_TITLE'] = 'Billing Statement';

?>
