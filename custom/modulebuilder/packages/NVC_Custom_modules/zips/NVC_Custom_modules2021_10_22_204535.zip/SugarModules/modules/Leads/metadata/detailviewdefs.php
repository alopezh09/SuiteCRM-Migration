<?php
$viewdefs ['Leads'] = 
array (
  'DetailView' => 
  array (
    'templateMeta' => 
    array (
      'form' => 
      array (
        'buttons' => 
        array (
          0 => 'EDIT',
          1 => 'DUPLICATE',
          2 => 'DELETE',
          4 => 'FIND_DUPLICATES',
          5 => 
          array (
            'customCode' => '<input title="{$APP.LBL_MANAGE_SUBSCRIPTIONS}" class="button" onclick="this.form.return_module.value=\'Leads\'; this.form.return_action.value=\'DetailView\';this.form.return_id.value=\'{$fields.id.value}\'; this.form.action.value=\'Subscriptions\'; this.form.module.value=\'Campaigns\'; this.form.module_tab.value=\'Leads\';" type="submit" name="Manage Subscriptions" value="{$APP.LBL_MANAGE_SUBSCRIPTIONS}">',
            'sugar_html' => 
            array (
              'type' => 'submit',
              'value' => '{$APP.LBL_MANAGE_SUBSCRIPTIONS}',
              'htmlOptions' => 
              array (
                'title' => '{$APP.LBL_MANAGE_SUBSCRIPTIONS}',
                'class' => 'button',
                'id' => 'manage_subscriptions_button',
                'onclick' => 'this.form.return_module.value=\'Leads\'; this.form.return_action.value=\'DetailView\';this.form.return_id.value=\'{$fields.id.value}\'; this.form.action.value=\'Subscriptions\'; this.form.module.value=\'Campaigns\'; this.form.module_tab.value=\'Leads\';',
                'name' => '{$APP.LBL_MANAGE_SUBSCRIPTIONS}',
              ),
            ),
          ),
          'AOS_GENLET' => 
          array (
            'customCode' => '<input type="button" class="button" onClick="showPopup();" value="{$APP.LBL_PRINT_AS_PDF}">',
          ),
        ),
        'headerTpl' => 'modules/Leads/tpls/DetailViewHeader.tpl',
      ),
      'maxColumns' => '2',
      'widths' => 
      array (
        0 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
        1 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
      ),
      'includes' => 
      array (
        0 => 
        array (
          'file' => 'modules/Leads/Lead.js',
        ),
      ),
      'useTabs' => true,
      'tabDefs' => 
      array (
        'LBL_CONTACT_INFORMATION' => 
        array (
          'newTab' => true,
          'panelDefault' => 'expanded',
        ),
        'LBL_PANEL_ADVANCED' => 
        array (
          'newTab' => true,
          'panelDefault' => 'expanded',
        ),
        'LBL_DETAILVIEW_PANEL1' => 
        array (
          'newTab' => true,
          'panelDefault' => 'expanded',
        ),
      ),
    ),
    'panels' => 
    array (
      'LBL_CONTACT_INFORMATION' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'first_name',
            'comment' => 'First name of the contact',
            'label' => 'LBL_FIRST_NAME',
          ),
          1 => 
          array (
            'name' => 'last_name',
            'comment' => 'Last name of the contact',
            'label' => 'LBL_LAST_NAME',
          ),
        ),
        1 => 
        array (
          0 => 'phone_mobile',
          1 => 
          array (
            'name' => 'phone_home',
            'comment' => 'Home phone number of the contact',
            'label' => 'LBL_HOME_PHONE',
          ),
        ),
        2 => 
        array (
          0 => 
          array (
            'name' => 'pasaporte_c',
            'label' => 'LBL_PASAPORTE',
          ),
          1 => 
          array (
            'name' => 'visa_c',
            'label' => 'LBL_VISA',
          ),
        ),
        3 => 
        array (
          0 => 'email1',
          1 => 
          array (
            'name' => 'ciudad_tmp_c',
            'label' => 'LBL_CIUDAD_TMP',
          ),
        ),
        4 => 
        array (
          0 => 
          array (
            'name' => 'pais_c',
            'studio' => 'visible',
            'label' => 'LBL_PAIS',
          ),
          1 => 
          array (
            'name' => 'departamento_c',
            'studio' => 'visible',
            'label' => 'LBL_DEPARTAMENTO',
          ),
        ),
        5 => 
        array (
          0 => 
          array (
            'name' => 'ciudad_c',
            'studio' => 'visible',
            'label' => 'LBL_CIUDAD',
          ),
        ),
        6 => 
        array (
          0 => 
          array (
            'name' => 'edad_c',
            'label' => 'LBL_EDAD',
          ),
          1 => 
          array (
            'name' => 'birthdate',
            'comment' => 'The birthdate of the contact',
            'label' => 'LBL_BIRTHDATE',
          ),
        ),
        7 => 
        array (
          0 => 
          array (
            'name' => 'fecha_expiracion_visa_c',
            'label' => 'LBL_FECHA_EXPIRACION_VISA',
          ),
          1 => 
          array (
            'name' => 'expiracion_visa_c',
            'label' => 'LBL_EXPIRACION_VISA',
          ),
        ),
        8 => 
        array (
          0 => 
          array (
            'name' => 'fecha_primer_presupuesto_c',
            'label' => 'LBL_FECHA_PRIMER_PRESUPUESTO',
          ),
        ),
        9 => 
        array (
          0 => 'description',
        ),
        10 => 
        array (
          0 => 
          array (
            'name' => 'industry_aplicant',
            'label' => 'LBL_INDUSTRY_APLICANT',
          ),
          1 => 
          array (
            'name' => 'consultation_date',
            'label' => 'LBL_CONSULTATION_DATE',
          ),
        ),
        11 => 
        array (
          0 => 
          array (
            'name' => 'aplicant_1st_payment_date',
            'label' => 'LBL_APPLICANT_1ST_PAYMENT_DATE',
          ),
          1 => 
          array (
            'name' => 'aplicant_first_payment_amount',
            'label' => 'LBL_APPLICANT_FIRST_PAYMENT_AMOUNT',
          ),
        ),
        12 => 
        array (
          0 => 
          array (
            'name' => 'profession',
            'label' => 'LBL_PROFESSION',
          ),
          1 => 
          array (
            'name' => 'current_visa_subclass',
            'label' => 'LBL_CURRENT_VISA_SUBCLASS',
          ),
        ),
        13 => 
        array (
          0 => 
          array (
            'name' => 'current_job_position',
            'label' => 'LBL_CURRENT_JOB_POSITION',
          ),
          1 => 
          array (
            'name' => 'month_of_experience',
            'label' => 'LBL_MONTHS_OF_EXPERIENCEL',
          ),
        ),
        14 => 
        array (
          0 => 
          array (
            'name' => 'level_of_english',
            'label' => 'LBL_LEVEL_OF_ENGLISH',
          ),
          1 => 
          array (
            'name' => 'nationality',
            'label' => 'LBL_NATIONALITY',
          ),
        ),
        15 => 
        array (
          0 => 
          array (
            'name' => 'potential_visa_subclass',
            'label' => 'LBL_POTENTIAL_VISA_SUBCLASS',
          ),
          1 => 
          array (
            'name' => 'cost_agrement_visa_subclass',
            'label' => 'LBL_COST_AGREMENT_NUMBER',
          ),
        ),
        16 => 
        array (
          0 => 
          array (
            'name' => 'cost_agrement_number',
            'label' => 'LBL_COST_AGREMENT_NUMBER',
          ),
          1 => 
          array (
            'name' => 'quote_date',
            'label' => 'LBL_QUOTE_DATE',
          ),
        ),
        17 => 
        array (
          0 => 
          array (
            'name' => 'migration_agent_namer',
            'label' => 'LBL_MIGRATION_AGENT_NAME',
          ),
          1 => 
          array (
            'name' => 'leap_id',
            'label' => 'LBL_LEAP_ID',
          ),
        ),
        18 => 
        array (
          0 => 
          array (
            'name' => 'recluter_name',
            'label' => 'LBL_RECLUTER_NAME',
          ),
          1 => 
          array (
            'name' => 'company_name',
            'label' => 'LBL_COMPANY_NAME',
          ),
        ),
        19 => 
        array (
          0 => 
          array (
            'name' => 'company_city',
            'label' => 'LBL_COMPANY_CITY',
          ),
          1 => 
          array (
            'name' => 'company_industry',
            'label' => 'LBL_COMPANY_INDUSTRY',
          ),
        ),
        20 => 
        array (
          0 => 
          array (
            'name' => 'email_company',
            'label' => 'LBL_EMAIL_COMPANY',
          ),
          1 => 
          array (
            'name' => 'phone_company',
            'label' => 'LBL_PHONE_COMPANY',
          ),
        ),
        21 => 
        array (
          0 => 
          array (
            'name' => 'company_1st_payment_date',
            'label' => 'LBL_COMPANY_1ST_PAYMENT_DATE',
          ),
          1 => 
          array (
            'name' => 'company_first_payment_amount',
            'label' => 'LBL_COMPANY_FIRST_PAYMENT_AMOUNT',
          ),
        ),
        22 => 
        array (
          0 => 
          array (
            'name' => 'company_sbs_expiry_date',
            'label' => 'LBL_COMPANY_SBS_EXPIRY_DATE',
          ),
          1 => 
          array (
            'name' => 'secondary_aplicant_name',
            'label' => 'LBL_SECONDARY_APLICANT_NAME',
          ),
        ),
        23 => 
        array (
          0 => 
          array (
            'name' => 'secondary_pasport_number',
            'label' => 'LBL_SECONDARY_PASPORT_NUMBER',
          ),
          1 => 
          array (
            'name' => 'secondary_dob',
            'label' => 'LBL_SECONDARY_DOB',
          ),
        ),
        24 => 
        array (
          0 => 
          array (
            'name' => 'dependent_name',
            'label' => 'LBL_DEPENDENT_NAME',
          ),
          1 => 
          array (
            'name' => 'dependent_dob',
            'label' => 'LBL_DEPENDENT_DOB',
          ),
        ),
        25 => 
        array (
          0 => 
          array (
            'name' => 'aplicant_mmm_fee',
            'label' => 'LBL_APLICANT_MMM_FEE',
          ),
          1 => 
          array (
            'name' => 'second_dependent_name',
            'label' => 'LBL_SECOND_DEPENDENT_NAME',
          ),
        ),
        26 => 
        array (
          0 => 
          array (
            'name' => 'second_dependent_dob',
            'label' => 'LBL_SECOND_DEPENDENT_DOB',
          ),
          1 => 
          array (
            'name' => 'third_dependent_name',
            'label' => 'LBL_THIRD_DEPENDENT_NAME',
          ),
        ),
        27 => 
        array (
          0 => 
          array (
            'name' => 'company_mmm_fee',
            'label' => 'LBL_COMPANY_MMM_FEE',
          ),
          1 => 
          array (
            'name' => 'aplicant_company_mmm',
            'label' => 'LBL_APLICANT_COMPANY_MMM',
          ),
        ),
        28 => 
        array (
          0 => 
          array (
            'name' => 'Total',
            'label' => 'LBL_TOTAL',
          ),
          1 => 
          array (
            'name' => 'aplicant_company_mmm_fees',
            'label' => 'LBL_APLICANT_COMPANY_MMM_FEES',
          ),
        ),
        29 => 
        array (
          0 => 
          array (
            'name' => 'total_paid',
            'label' => 'LBL_TOTAL_PAID',
          ),
          1 => 
          array (
            'name' => 'ocupation',
            'label' => 'LBL_OCUPATION',
          ),
        ),
        30 => 
        array (
          0 => 
          array (
            'name' => 'main_aplicant_name',
            'label' => 'LBL_MAIN_APLICANT_NAME',
          ),
        ),
      ),
      'LBL_PANEL_ADVANCED' => 
      array (
        0 => 
        array (
          0 => 'status',
          1 => 
          array (
            'name' => 'assigned_user_name',
            'label' => 'LBL_ASSIGNED_TO',
          ),
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'carrera_universitaria_c',
            'label' => 'LBL_CARRERA_UNIVERSITARIA',
          ),
          1 => 
          array (
            'name' => 'trabajo_actual_c',
            'label' => 'LBL_TRABAJO_ACTUAL',
          ),
        ),
        2 => 
        array (
          0 => 
          array (
            'name' => 'date_entered',
            'customCode' => '{$fields.date_entered.value} {$APP.LBL_BY} {$fields.created_by_name.value}',
          ),
          1 => 
          array (
            'name' => 'date_modified',
            'label' => 'LBL_DATE_MODIFIED',
            'customCode' => '{$fields.date_modified.value} {$APP.LBL_BY} {$fields.modified_by_name.value}',
          ),
        ),
      ),
      'lbl_detailview_panel1' => 
      array (
        0 => 
        array (
          0 => 'lead_source',
          1 => 
          array (
            'name' => 'campana_c',
            'studio' => 'visible',
            'label' => 'LBL_CAMPANA',
          ),
        ),
      ),
    ),
  ),
);
;
?>
