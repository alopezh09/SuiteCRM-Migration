<?php
$module_name = 'Veta_Recibo';
$viewdefs [$module_name] = 
array (
  'EditView' => 
  array (
    'templateMeta' => 
    array (
      'form' => 
      array (
        'hidden' => 
        array (
          0 => '<input type="hidden" id="asegurador" name="asegurador" value="{$fields.asegurador.value}">',
        ),
      ),
      'includes' => 
      array (
        0 => 
        array (
          'file' => 'modules/Veta_Recibo/javascript/seguro_soel.js',
        ),
      ),
      'maxColumns' => '2',
      'widths' => 
      array (
        0 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
        1 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
      ),
      'useTabs' => false,
      'tabDefs' => 
      array (
        'DEFAULT' => 
        array (
          'newTab' => false,
          'panelDefault' => 'expanded',
        ),
        'LBL_EDITVIEW_PANEL1' => 
        array (
          'newTab' => false,
          'panelDefault' => 'expanded',
        ),
      ),
    ),
    'panels' => 
    array (
      'default' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'components',
            'studio' => 'visible',
            'label' => 'LBL_COMPONENT',
          ),
          1 => 
          array (
            'name' => 'concept',
            'studio' => 'visible',
            'label' => 'LBL_CONCEPT',
          ),
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'fee',
            'studio' => 'visible',
            'label' => 'LBL_FEE',
          ),
          1 => 
          array (
            'name' => 'tipo_visa',
            'studio' => 'visible',
            'label' => 'LBL_TIPO_VISA',
          ),
        ),
        2 => 
        array (
          0 => 
          array (
            'name' => 'estado',
            'studio' => 'visible',
            'label' => 'LBL_ESTADO',
          ),
          1 => '',
        ),
        3 => 
        array (
          0 => 
          array (
            'name' => 'descuento',
            'label' => 'LBL_DESCUENTO',
          ),
          1 => 
          array (
            'name' => 'company_discount_c',
            'label' => 'LBL_COMPANY_DISCOUNT',
          ),
        ),
        4 => 
        array (
          0 => 'description',
        ),
      ),
      'lbl_editview_panel1' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'soel_asegurador',
            'label' => 'LBL_SOEL_ASEGURADOR',
            'type' => 'enum',
            'function' => 
            array (
              'name' => 'getAseguradores',
            ),
          ),
          1 => 
          array (
            'name' => 'seguro',
            'label' => 'LBL_SEGURO',
          ),
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'duracion',
            'label' => 'LBL_DURACION',
          ),
          1 => 
          array (
            'name' => 'tipo_seguro',
            'studio' => 'visible',
            'label' => 'LBL_TIPO_SEGURO',
          ),
        ),
      ),
    ),
  ),
);
;
?>
