<?php 
 // created: 2021-10-22 20:44:30
$mod_strings['LBL_NAME'] = 'Number';

?>
