<?php 
 // created: 2021-10-22 20:44:51
$mod_strings['LBL_PAIS'] = 'Country';
$mod_strings['LBL_GRAN_TOTAL'] = 'Total';
$mod_strings['LBL_COMPANY_DISCOUNT'] = 'Company Discount';
$mod_strings['LBL_NAME'] = 'Number';
$mod_strings['LBL_COMPANY_TOTAL_VISA'] = 'Company Total Visa';
$mod_strings['LBL_COMPANY_TOTAL_VISA_C'] = 'company total visa c';
$mod_strings['LBL_TOTAL_VISA_COMPANY'] = 'Total Visa Company';

?>
