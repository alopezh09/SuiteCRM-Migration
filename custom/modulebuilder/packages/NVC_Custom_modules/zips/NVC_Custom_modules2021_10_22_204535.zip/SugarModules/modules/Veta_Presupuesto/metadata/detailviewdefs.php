<?php
$module_name = 'Veta_Presupuesto';
$viewdefs [$module_name] = 
array (
  'DetailView' => 
  array (
    'templateMeta' => 
    array (
      'form' => 
      array (
        'buttons' => 
        array (
          0 => 'EDIT',
          1 => 'DUPLICATE',
          2 => 'DELETE',
          3 => 'FIND_DUPLICATES',
          4 => 
          array (
            'customCode' => '<input value="Create Invoice" type="button" class="button" onClick="document.location=\'index.php?module=Veta_Recibo&action=recibo&pid=\'+ document.getElementsByName(\'record\')[0].value" >',
          ),
          5 => 
          array (
            'customCode' => '<input value="Download Applicant PDF" target="_blank" type="button" class="button" onClick="document.location=\'index.php?module=Veta_Presupuesto&action=pdf&pid=\'+ document.getElementsByName(\'record\')[0].value" >',
          ),
          6 => 
          array (
            'customCode' => '<input value="Download Company PDF" type="button" class="button" onClick="document.location=\'index.php?module=Veta_Presupuesto&action=pdf_company&pid=\'+ document.getElementsByName(\'record\')[0].value" >',
          ),
          7 => 
          array (
            'customCode' => '<input value="Send Applicant Budget" type="button" class="button" onClick="document.location=\'index.php?module=Veta_Presupuesto&action=send&pid=\'+ document.getElementsByName(\'record\')[0].value" >',
          ),
          8 => 
          array (
            'customCode' => '<input value="Send Company Budget" type="button" class="button" onClick="document.location=\'index.php?module=Veta_Presupuesto&action=send_company&pid=\'+ document.getElementsByName(\'record\')[0].value" >',
          ),
          9 => 
          array (
            'customCode' => '<input value="Send Applicant / Company Budget #Pendiente de programar" type="button" class="button" onClick="document.location=\'index.php?module=Veta_Presupuesto&action=send_company&pid=\'+ document.getElementsByName(\'record\')[0].value" >',
          ),
        ),
      ),
      'maxColumns' => '2',
      'widths' => 
      array (
        0 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
        1 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
      ),
      'useTabs' => false,
      'tabDefs' => 
      array (
        'DEFAULT' => 
        array (
          'newTab' => false,
          'panelDefault' => 'expanded',
        ),
        'LBL_DETAILVIEW_PANEL1' => 
        array (
          'newTab' => false,
          'panelDefault' => 'expanded',
        ),
        'LBL_DETAILVIEW_PANEL2' => 
        array (
          'newTab' => false,
          'panelDefault' => 'expanded',
        ),
      ),
    ),
    'panels' => 
    array (
      'default' => 
      array (
        0 => 
        array (
          0 => 'name',
          1 => 
          array (
            'name' => 'assigned_user_name',
            'label' => 'LBL_ASSIGNED_TO_NAME',
          ),
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'concept',
            'studio' => 'visible',
            'label' => 'LBL_CONCEPT',
          ),
          1 => 
          array (
            'name' => 'fee',
            'studio' => 'visible',
            'label' => 'LBL_FEE',
          ),
        ),
        2 => 
        array (
          0 => 
          array (
            'name' => 'date_entered',
            'customCode' => '{$fields.date_entered.value} {$APP.LBL_BY} {$fields.created_by_name.value}',
            'label' => 'LBL_DATE_ENTERED',
          ),
          1 => 
          array (
            'name' => 'date_modified',
            'customCode' => '{$fields.date_modified.value} {$APP.LBL_BY} {$fields.modified_by_name.value}',
            'label' => 'LBL_DATE_MODIFIED',
          ),
        ),
      ),
      'lbl_detailview_panel1' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'examen_medico',
            'label' => 'LBL_EXAMEN_MEDICO',
          ),
          1 => '',
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'asegurador',
            'label' => 'LBL_ASEGURADOR',
          ),
          1 => 
          array (
            'name' => 'duracion',
            'label' => 'LBL_DURACION',
          ),
        ),
        2 => 
        array (
          0 => 
          array (
            'name' => 'tipo_seguro',
            'studio' => 'visible',
            'label' => 'LBL_TIPO_SEGURO',
          ),
          1 => 
          array (
            'name' => 'seguro',
            'label' => 'LBL_SEGURO',
          ),
        ),
        3 => 
        array (
          0 => 
          array (
            'name' => 'tipo_visa',
            'studio' => 'visible',
            'label' => 'LBL_TIPO_VISA',
          ),
          1 => 
          array (
            'name' => 'total_visa',
            'label' => 'LBL_TOTAL_VISA',
          ),
        ),
        4 => 
        array (
          0 => 
          array (
            'name' => 'total_visa_company_c',
            'label' => 'LBL_TOTAL_VISA_COMPANY',
          ),
          1 => '',
        ),
      ),
      'lbl_detailview_panel2' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'descuento',
            'label' => 'LBL_DESCUENTO',
          ),
          1 => 
          array (
            'name' => 'company_discount_c',
            'label' => 'LBL_COMPANY_DISCOUNT',
          ),
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'gran_total',
            'label' => 'LBL_GRAN_TOTAL',
          ),
        ),
      ),
    ),
  ),
);
;
?>
