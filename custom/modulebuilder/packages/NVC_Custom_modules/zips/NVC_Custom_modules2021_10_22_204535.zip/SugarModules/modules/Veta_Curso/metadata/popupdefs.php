<?php
$popupMeta = array (
    'moduleMain' => 'Veta_Curso',
    'varName' => 'Veta_Curso',
    'orderBy' => 'veta_curso.name',
    'whereClauses' => array (
  'name' => 'veta_curso.name',
  'college' => 'veta_curso.college',
  'tipo_curso' => 'veta_curso.tipo_curso',
  'activo' => 'veta_curso.activo',
  'duracion' => 'veta_curso.duracion',
  'campus' => 'veta_curso.campus',
  'jornada' => 'veta_curso.jornada',
  'created_by_name' => 'veta_curso.created_by_name',
),
    'searchInputs' => array (
  1 => 'name',
  4 => 'tipovisa',
  5 => 'tipo_curso',
  6 => 'activo',
  7 => 'duracion',
  8 => 'campus',
  9 => 'jornada',
  10 => 'created_by_name',
),
    'searchdefs' => array (
  'name' => 
  array (
    'name' => 'name',
    'width' => '10%',
  ),

  'tipovisa' => 
  array (
    'type' => 'dynamicenum',
    'studio' => 'visible',
    'id' => 'VETA_TIPOSVISA_ID_C',
    'label' => 'LBL_TIPOVISA',
    'width' => '10%',
    'default' => true,
    'name' => 'tipovisa',
  ),
  

      'description' => 
      array (
        'type' => 'text',
        'studio' => 'visible',
        'label' => 'LBL_DESCRIPTION',
        'link' => true,
        'width' => '10%',
        'default' => true,
        'name' => 'description',
      ),
      
),
);
