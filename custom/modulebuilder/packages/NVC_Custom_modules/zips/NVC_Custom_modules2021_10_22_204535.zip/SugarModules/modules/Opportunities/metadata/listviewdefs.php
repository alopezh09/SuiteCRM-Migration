<?php
$listViewDefs ['Opportunities'] = 
array (
  'NAME' => 
  array (
    'width' => '30%',
    'label' => 'LBL_LIST_OPPORTUNITY_NAME',
    'link' => true,
    'default' => true,
  ),
  'SALES_STAGE' => 
  array (
    'width' => '10%',
    'label' => 'LBL_LIST_SALES_STAGE',
    'default' => true,
  ),
  'AMOUNT' => 
  array (
    'type' => 'currency',
    'label' => 'LBL_AMOUNT',
    'currency_format' => true,
    'width' => '10%',
    'default' => true,
  ),
  'LEAD_SOURCE' => 
  array (
    'width' => '15%',
    'label' => 'LBL_LEAD_SOURCE',
    'default' => true,
  ),
  'CAMPAIGN_NAME' => 
  array (
    'type' => 'relate',
    'link' => true,
    'label' => 'LBL_CAMPAIGN',
    'id' => 'CAMPAIGN_ID',
    'width' => '10%',
    'default' => true,
  ),
  'DATE_CLOSED' => 
  array (
    'width' => '10%',
    'label' => 'LBL_LIST_DATE_CLOSED',
    'default' => true,
  ),
  'ASSIGNED_USER_NAME' => 
  array (
    'width' => '5%',
    'label' => 'LBL_LIST_ASSIGNED_USER',
    'module' => 'Employees',
    'id' => 'ASSIGNED_USER_ID',
    'default' => true,
  ),
  'ASIGNADO_SERVICIO_CLIENTE_C' => 
  array (
    'type' => 'relate',
    'default' => true,
    'studio' => 'visible',
    'label' => 'LBL_ASIGNADO_SERVICIO_CLIENTE',
    'id' => 'USER_ID2_C',
    'link' => true,
    'width' => '10%',
  ),
  'ASIGNADO_APLICACION_C' => 
  array (
    'type' => 'relate',
    'default' => true,
    'studio' => 'visible',
    'label' => 'LBL_ASIGNADO_APLICACION',
    'id' => 'USER_ID_C',
    'link' => true,
    'width' => '10%',
  ),
  'ASIGNADO_VISAS_C' => 
  array (
    'type' => 'relate',
    'default' => true,
    'studio' => 'visible',
    'label' => 'LBL_ASIGNADO_VISAS',
    'id' => 'USER_ID1_C',
    'link' => true,
    'width' => '10%',
  ),
  'ESTADO_ADMISIONES_C' => 
  array (
    'type' => 'enum',
    'default' => true,
    'studio' => 'visible',
    'label' => 'LBL_ESTADO_ADMISIONES',
    'width' => '10%',
  ),
  'ESTADO_GESTION_COMERCIAL_C' => 
  array (
    'type' => 'enum',
    'default' => true,
    'studio' => 'visible',
    'label' => 'LBL_ESTADO_GESTION_COMERCIAL',
    'width' => '10%',
  ),
  'ESTADO_SERVICIO_AL_CLIENTE_C' => 
  array (
    'type' => 'enum',
    'default' => true,
    'studio' => 'visible',
    'label' => 'LBL_ESTADO_SERVICIO_AL_CLIENTE',
    'width' => '10%',
  ),
  'ESTADO_PAGO_INSTITUCION_C' => 
  array (
    'type' => 'enum',
    'default' => true,
    'studio' => 'visible',
    'label' => 'LBL_ESTADO_PAGO_INSTITUCION',
    'width' => '10%',
  ),
  'ESTADO_CARTERA_C' => 
  array (
    'type' => 'enum',
    'default' => true,
    'studio' => 'visible',
    'label' => 'LBL_ESTADO_CARTERA',
    'width' => '10%',
  ),
  'ESTADO_VISAS_C' => 
  array (
    'type' => 'enum',
    'default' => true,
    'studio' => 'visible',
    'label' => 'LBL_ESTADO_VISAS',
    'width' => '10%',
  ),
  'DATE_ENTERED' => 
  array (
    'width' => '10%',
    'label' => 'LBL_DATE_ENTERED',
    'default' => true,
  ),
  'FECHA_PRESUPUESTO_C' => 
  array (
    'type' => 'date',
    'default' => true,
    'label' => 'LBL_FECHA_PRESUPUESTO',
    'width' => '10%',
  ),
  'SOEL_FECHA_VIAJE' => 
  array (
    'type' => 'datetime',
    'label' => 'LBL_SOEL_FECHA_VIAJE',
    'width' => '10%',
    'default' => true,
    'sortable' => false,
  ),
  'SOEL_FECHA_EXPIRACION_VISA' => 
  array (
    'type' => 'datetime',
    'label' => 'LBL_SOEL_FECHA_EXPIRACION_VISA',
    'width' => '10%',
    'default' => true,
    'sortable' => false,
  ),
  'LEADS_OPPORTUNITIES_1_NAME' => 
  array (
    'type' => 'relate',
    'link' => true,
    'label' => 'LBL_LEADS_OPPORTUNITIES_1_FROM_LEADS_TITLE',
    'id' => 'LEADS_OPPORTUNITIES_1LEADS_IDA',
    'width' => '10%',
    'default' => true,
  ),
  'CONTACTS_OPPORTUNITIES_1_NAME' => 
  array (
    'type' => 'relate',
    'link' => true,
    'label' => 'LBL_CONTACTS_OPPORTUNITIES_1_FROM_CONTACTS_TITLE',
    'id' => 'CONTACTS_OPPORTUNITIES_1CONTACTS_IDA',
    'width' => '10%',
    'default' => true,
  ),
  'SOEL_VISTO_BUENO_COMERCIAL' => 
  array (
    'type' => 'bool',
    'label' => 'LBL_SOEL_VISTO_BUENO_COMERCIAL',
    'width' => '10%',
    'default' => true,
    'sortable' => false,
  ),
  'SOEL_VISTO_BUENO_VISAS' => 
  array (
    'type' => 'bool',
    'label' => 'LBL_SOEL_VISTO_BUENO_VISAS',
    'width' => '10%',
    'default' => true,
    'sortable' => false,
  ),
  'SOEL_OFICINA' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_SOEL_OFICINA',
    'width' => '10%',
    'default' => true,
    'sortable' => false,
  ),
  'INDUSTRY_APLICANT' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_INDUSTRY_APLICANT',
    'width' => '10%',
    'default' => true,
  ),
  'CONSULTATION_DATE' => 
  array (
    'type' => 'date',
    'label' => 'LBL_CONSULTATION_DATE',
    'width' => '10%',
    'default' => true,
  ),
  'APPLICANT_1ST_PAYMENT_DATE' => 
  array (
    'type' => 'date',
    'label' => 'LBL_APPLICANT_1ST_PAYMENT_DATE',
    'width' => '10%',
    'default' => true,
  ),
  'APPLICANT_FIRST_PAYMENT_AMOUNT' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_APPLICANT_FIRST_PAYMENT_AMOUNT',
    'width' => '10%',
    'default' => true,
  ),
  'PROFESSION' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_PROFESSION',
    'width' => '10%',
    'default' => true,
  ),
  'CURRENT_VISA_SUBCLASS' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_CURRENT_VISA_SUBCLASS',
    'width' => '10%',
    'default' => true,
  ),
  'CURRENT_JOB_POSITION' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_CURRENT_JOB_POSITION',
    'width' => '10%',
    'default' => true,
  ),
  'MONTHS_OF_EXPERIENCE' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_MONTHS_OF_EXPERIENCEL',
    'width' => '10%',
    'default' => true,
  ),
  'LEVEL_OF_ENGLISH' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_LEVEL_OF_ENGLISH',
    'width' => '10%',
    'default' => true,
  ),
  'NATIONALITY' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_NATIONALITY',
    'width' => '10%',
    'default' => true,
  ),
  'POTENTIAL_VISA_SUBCLASS' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_POTENTIAL_VISA_SUBCLASS',
    'width' => '10%',
    'default' => true,
  ),
  'COST_AGREMENT_NUMBER' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_COST_AGREMENT_NUMBER',
    'width' => '10%',
    'default' => true,
  ),
  'COST_AGREMENT_VISA_SUBCLASS' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_COST_AGREMENT_VISA_SUBCLASS',
    'width' => '10%',
    'default' => true,
  ),
  'QUOTE_DATE' => 
  array (
    'type' => 'date',
    'label' => 'LBL_QUOTE_DATE',
    'width' => '10%',
    'default' => true,
  ),
  'MIGRATION_AGENT_NAME' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_MIGRATION_AGENT_NAME',
    'width' => '10%',
    'default' => true,
  ),
  'LEAP_ID' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_LEAP_ID',
    'width' => '10%',
    'default' => true,
  ),
  'RECLUTER_NAME' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_RECLUTER_NAME',
    'width' => '10%',
    'default' => true,
  ),
  'COMPANY_NAME' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_COMPANY_NAME',
    'width' => '10%',
    'default' => true,
  ),
  'COMPANY_CITY' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_COMPANY_CITY',
    'width' => '10%',
    'default' => true,
  ),
  'COMPANY_INDUSTRY' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_COMPANY_INDUSTRY',
    'width' => '10%',
    'default' => true,
  ),
  'EMAIL_COMPANY' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_EMAIL_COMPANY',
    'width' => '10%',
    'default' => true,
  ),
  'PHONE_COMPANY' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_PHONE_COMPANY',
    'width' => '10%',
    'default' => true,
  ),
  'COMPANY_1ST_PAYMENT_DATE' => 
  array (
    'type' => 'date',
    'label' => 'LBL_COMPANY_1ST_PAYMENT_DATE',
    'width' => '10%',
    'default' => true,
  ),
  'COMPANY_FIRST_PAYMENT_AMOUNT' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_COMPANY_FIRST_PAYMENT_AMOUNT',
    'width' => '10%',
    'default' => true,
  ),
  'COMPANY_SBS_EXPIRY_DATE' => 
  array (
    'type' => 'date',
    'label' => 'LBL_COMPANY_SBS_EXPIRY_DATE',
    'width' => '10%',
    'default' => true,
  ),
  'SECONDARY_APLICANT_NAME' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_SECONDARY_APLICANT_NAME',
    'width' => '10%',
    'default' => true,
  ),
  'SECONDARY_PASPORT_NUMBER' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_SECONDARY_PASPORT_NUMBER',
    'width' => '10%',
    'default' => true,
  ),
  'SECONDARY_DOB' => 
  array (
    'type' => 'date',
    'label' => 'LBL_SECONDARY_DOB',
    'width' => '10%',
    'default' => true,
  ),
  'DEPENDENT_NAME' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_DEPENDENT_NAME',
    'width' => '10%',
    'default' => true,
  ),
  'DEPENDENT_DOB' => 
  array (
    'type' => 'date',
    'label' => 'LBL_DEPENDENT_DOB',
    'width' => '10%',
    'default' => true,
  ),
  'SECOND_DEPENDENT_NAME' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_SECOND_DEPENDENT_NAME',
    'width' => '10%',
    'default' => true,
  ),
  'SECOND_DEPENDENT_DOB' => 
  array (
    'type' => 'date',
    'label' => 'LBL_SECOND_DEPENDENT_DOB',
    'width' => '10%',
    'default' => true,
  ),
  'THIRD_DEPENDENT_NAME' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_THIRD_DEPENDENT_NAME',
    'width' => '10%',
    'default' => true,
  ),
  'APLICANT_DEPARTMENTS_VISA_FEE' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_APLICANT_DEPARTMENTS_VISA_FEE',
    'width' => '10%',
    'default' => true,
  ),
  'COMPANY_MMM_FEE' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_COMPANY_MMM_FEE',
    'width' => '10%',
    'default' => true,
  ),
  'APLICANT_COMPANY_MMM' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_APLICANT_COMPANY_MMM',
    'width' => '10%',
    'default' => true,
  ),
  'TOTAL' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_TOTAL',
    'width' => '10%',
    'default' => false,
  ),
  'APLICANT_COMPANY_MMM_FEES' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_APLICANT_COMPANY_MMM_FEES',
    'width' => '10%',
    'default' => true,
  ),
  'TOTAL_PAID' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_TOTAL_PAID',
    'width' => '10%',
    'default' => true,
  ),
  'OCUPATION' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_OCUPATION',
    'width' => '10%',
    'default' => true,
  ),
  'MAIN_APLICANT_NAME' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_MAIN_APLICANT_NAME',
    'width' => '10%',
    'default' => true,
  ),
  'NOMINATION_APP_EXP_DATE' => 
  array (
    'type' => 'date',
    'label' => 'LBL_NOMINATION_APP_EXP_DATE',
    'width' => '10%',
    'default' => true,
  ),
  'NOMINATION_APP_DATE' => 
  array (
    'type' => 'date',
    'label' => 'LBL_NOMINATION_APP_DATE',
    'width' => '10%',
    'default' => true,
  ),
  'SKILL_ASSESSMENT_APP_EXP_DATE' => 
  array (
    'type' => 'date',
    'label' => 'LBL_SKILL_ASSESSMENT_APP_EXP_DATE',
    'width' => '10%',
    'default' => true,
  ),
  'SKILL_ASSESSMENT_APP_DATE' => 
  array (
    'type' => 'date',
    'label' => 'LBL_SKILL_ASSESSMENT_APP_DATE',
    'width' => '10%',
    'default' => true,
  ),
  'VISA_APP_EXP_DATE' => 
  array (
    'type' => 'date',
    'label' => 'LBL_VISA_APP_EXP_DATE',
    'width' => '10%',
    'default' => true,
  ),
  'VISA_APP_DATE' => 
  array (
    'type' => 'date',
    'label' => 'LBL_VISA_APP_DATE',
    'width' => '10%',
    'default' => true,
  ),
  'RECRUITMENT' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_RECRUITMENT',
    'width' => '10%',
    'default' => true,
  ),
  'RECRUITMENT_EXP_DATE' => 
  array (
    'type' => 'date',
    'label' => 'LBL_RECRUITMENT_EXP_DATE',
    'width' => '10%',
    'default' => true,
  ),
  'FECHA_CIERRE_C' => 
  array (
    'type' => 'date',
    'label' => 'LBL_FECHA_CIERRE',
    'width' => '10%',
    'default' => true,
  ),
  'COMPANY_TOTAL_C' => 
  array (
    'type' => 'currency',
    'default' => true,
    'label' => 'LBL_COMPANY_TOTAL',
    'currency_format' => true,
    'width' => '10%',
  ),
  'COMPANY_OUTSTANDING_AMOUNT_C' => 
  array (
    'type' => 'currency',
    'default' => true,
    'label' => 'LBL_COMPANY_OUTSTANDING_AMOUNT',
    'currency_format' => true,
    'width' => '10%',
  ),
  'DISCOUNT' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_DISCOUNT',
    'width' => '10%',
    'default' => true,
  ),
  'TOTAL_WITHOUT_GST' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_TOTAL_WITHOUT_GST',
    'width' => '10%',
    'default' => true,
  ),
  'APLICANT_MMM_FEE' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_APLICANT_MMM_FEE',
    'width' => '10%',
    'default' => true,
  ),
  'GST_PERCENTAGE' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_GST_PERCENTAGE',
    'width' => '10%',
    'default' => true,
  ),
  'CONSULTATION_FEE' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_CONSULTATION_FEE',
    'width' => '10%',
    'default' => true,
  ),
  'INSURANCE_VALUE' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_INSURANCE_VALUE',
    'width' => '10%',
    'default' => true,
  ),
  'DEPARTMENT_VISA_FEE_BASE_APPLICATION_CHARGE' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_DEPARTMENT_VISA_FEE_BASE_APPLICATION_CHARGE',
    'width' => '10%',
    'default' => true,
  ),
  'DEPARTMENT_CREDIT_CARD_SURCHARGE_PERCENTAGE' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_DEPARTMENT_CREDIT_CARD_SURCHARGE_PERCENTAGE',
    'width' => '10%',
    'default' => true,
  ),
  'MONTO_DOLARES_AUSTRALIANOS_C' => 
  array (
    'type' => 'int',
    'default' => true,
    'label' => 'LBL_MONTO_DOLARES_AUSTRALIANOS',
    'width' => '10%',
  ),
  'DEPOSIT' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_DEPOSIT',
    'width' => '10%',
    'default' => true,
  ),
  'OUTSTANDING_AMOUNT' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_OUTSTANDING_AMOUNT',
    'width' => '10%',
    'default' => true,
  ),
  'DATE_MODIFIED' => 
  array (
    'type' => 'datetime',
    'label' => 'LBL_DATE_MODIFIED',
    'width' => '10%',
    'default' => false,
  ),
  'CREATED_BY_NAME' => 
  array (
    'width' => '10%',
    'label' => 'LBL_CREATED',
    'default' => false,
  ),
  'SOEL_DOCS_PENDIENTES' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_SOEL_DOCS_PENDIENTES',
    'width' => '10%',
    'default' => false,
  ),
  'SOEL_DATE_ASESOR' => 
  array (
    'type' => 'datetime',
    'label' => 'LBL_SOEL_DATE_ASESOR',
    'width' => '10%',
    'default' => false,
  ),
  'SOEL_DATE_ESTUDIANTE' => 
  array (
    'type' => 'datetime',
    'label' => 'LBL_SOEL_DATE_ESTUDIANTE',
    'width' => '10%',
    'default' => false,
  ),
  'MODIFIED_BY_NAME' => 
  array (
    'width' => '5%',
    'label' => 'LBL_MODIFIED',
    'default' => false,
  ),
  'PENDIENTE_PAGO_COLEGIOS_C' => 
  array (
    'type' => 'currency',
    'default' => false,
    'label' => 'LBL_PENDIENTE_PAGO_COLEGIOS',
    'currency_format' => true,
    'width' => '10%',
  ),
  'PENDIENTE_CARTERA_C' => 
  array (
    'type' => 'currency',
    'default' => false,
    'label' => 'LBL_PENDIENTE_CARTERA',
    'currency_format' => true,
    'width' => '10%',
  ),
  'FECHA_PROXIMO_CONTACTO_C' => 
  array (
    'type' => 'datetimecombo',
    'default' => false,
    'label' => 'LBL_FECHA_PROXIMO_CONTACTO',
    'width' => '10%',
  ),
  'FECHA_ULTIMO_CONTACTO_C' => 
  array (
    'type' => 'datetimecombo',
    'default' => false,
    'label' => 'LBL_FECHA_ULTIMO_CONTACTO',
    'width' => '10%',
  ),
  'SOEL_DOCS_SOLICITADOS' => 
  array (
    'type' => 'varchar',
    'default' => false,
    'label' => 'LBL_SOEL_DOCS_SOLICITADOS',
    'width' => '10%',
  ),
  'SOEL_REFERIDO' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_SOEL_REFERIDO',
    'width' => '10%',
    'default' => false,
  ),
  'COMPANY_GST_C' => 
  array (
    'type' => 'currency',
    'default' => false,
    'label' => 'LBL_COMPANY_GST',
    'currency_format' => true,
    'width' => '10%',
  ),
  'COMPANY_TOTAL_WITHOUT_GST_C' => 
  array (
    'type' => 'currency',
    'default' => false,
    'label' => 'LBL_COMPANY_TOTAL_WITHOUT_GST',
    'currency_format' => true,
    'width' => '10%',
  ),
  'COMPANY_LEAD_ID_C' => 
  array (
    'type' => 'currency',
    'default' => false,
    'label' => 'LBL_COMPANY_LEAD_ID',
    'currency_format' => true,
    'width' => '10%',
  ),
  'COMPANY_DEPT_VISA_FEE_BASE_C' => 
  array (
    'type' => 'currency',
    'default' => false,
    'label' => 'LBL_COMPANY_DEPT_VISA_FEE_BASE',
    'currency_format' => true,
    'width' => '10%',
  ),
  'COMPANY_DEPT_CC_SURCHARGE_C' => 
  array (
    'type' => 'currency',
    'default' => false,
    'label' => 'LBL_COMPANY_DEPT_CC_SURCHARGE_C',
    'currency_format' => true,
    'width' => '10%',
  ),
  'COMPANY_DISCOUNT_C' => 
  array (
    'type' => 'currency',
    'default' => false,
    'label' => 'LBL_COMPANY_DISCOUNT',
    'currency_format' => true,
    'width' => '10%',
  ),
  'COMPANY_DEPOSITS_C' => 
  array (
    'type' => 'currency',
    'default' => false,
    'label' => 'LBL_COMPANY_DEPOSITS',
    'currency_format' => true,
    'width' => '10%',
  ),
  'FECHA_APLICACION_VISA_C' => 
  array (
    'type' => 'date',
    'default' => false,
    'label' => 'LBL_FECHA_APLICACION_VISA',
    'width' => '10%',
  ),
);
;
?>
