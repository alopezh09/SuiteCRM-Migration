<?php
// created: 2024-09-24 17:15:55
$dictionary["Auto_Recordatorio"]["fields"]["auto_recordatorio_emails"] = array (
  'name' => 'auto_recordatorio_emails',
  'type' => 'link',
  'relationship' => 'auto_recordatorio_emails',
  'source' => 'non-db',
  'module' => 'Emails',
  'bean_name' => 'Email',
  'side' => 'right',
  'vname' => 'LBL_AUTO_RECORDATORIO_EMAILS_FROM_EMAILS_TITLE',
);
