<?php
 // created: 2024-09-24 17:15:55
$layout_defs["Auto_Recordatorio"]["subpanel_setup"]['auto_recordatorio_emails'] = array (
  'order' => 100,
  'module' => 'Emails',
  'subpanel_name' => 'ForQueues',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_AUTO_RECORDATORIO_EMAILS_FROM_EMAILS_TITLE',
  'get_subpanel_data' => 'auto_recordatorio_emails',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
