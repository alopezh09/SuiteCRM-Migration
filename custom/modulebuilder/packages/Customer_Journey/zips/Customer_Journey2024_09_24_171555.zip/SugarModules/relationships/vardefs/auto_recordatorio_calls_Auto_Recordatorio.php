<?php
// created: 2024-09-24 17:15:55
$dictionary["Auto_Recordatorio"]["fields"]["auto_recordatorio_calls"] = array (
  'name' => 'auto_recordatorio_calls',
  'type' => 'link',
  'relationship' => 'auto_recordatorio_calls',
  'source' => 'non-db',
  'module' => 'Calls',
  'bean_name' => 'Call',
  'side' => 'right',
  'vname' => 'LBL_AUTO_RECORDATORIO_CALLS_FROM_CALLS_TITLE',
);
